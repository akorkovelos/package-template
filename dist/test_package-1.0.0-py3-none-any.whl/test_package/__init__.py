"""
test_code package contains the following modules:

 - test_package.py : main functions of the model
"""

__version__ = "1.0.0"

from .test_package import *
