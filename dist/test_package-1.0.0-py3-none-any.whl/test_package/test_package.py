from __future__ import print_function

def hello():
    """Return a intro sample message"""
    return ("This is a sample package")

def say_hello():
    """Prints a sample message"""
    print (hello())